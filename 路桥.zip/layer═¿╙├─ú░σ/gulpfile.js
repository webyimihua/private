var prod = require('./config/gulpfile.prod.js');
var dev = require('./config/gulpfile.dev.js');
dev();
prod();
